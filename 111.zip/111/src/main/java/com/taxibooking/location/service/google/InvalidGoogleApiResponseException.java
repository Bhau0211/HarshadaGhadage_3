/**
 * 
 */
package com.taxibooking.location.service.google;

/**
 * @author vinodkandula
 *
 */
public class InvalidGoogleApiResponseException extends Exception {

}
